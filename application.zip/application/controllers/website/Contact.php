<?php

class Contact extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper(array('form'));

		$this->load->model('WebsiteModel');	
	}

	public function index() {
		$this->load->view('layouts/header');
		$this->load->view('website/contact');
		$this->load->view('layouts/footer');
	}

	public function submit() {
		$username = $this->input->post('txtName');
		$email = $this->input->post('txtEmail');
		$phone_number = $this->input->post('txtPhoneno');
		$province = $this->input->post('txtprovince');
		$message = $this->input->post('txtMessage');

		$data = array(
			'username' => $username,
			'email' => $email,
			'contact' => $phone_number,
			'province' => $province,
			'message' => $message
		);

		$save = $this->WebsiteModel->save_query($data);
		if($save) {
			$this->session->set_flashdata('success', 'Query submitted successfully');
			return redirect(base_url().'website/Contact');
		} else {
			$this->session->set_flashdata('warning', 'Query could not be submitted');
			return redirect(base_url().'website/Contact');
		}
	}
}

?>