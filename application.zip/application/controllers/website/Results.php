<?php 

class Results extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper(array('form'));

		$this->load->model('WebsiteModel');	
	}

	public function index() {
// 		$this->load->view('layouts/header2');
        $this->load->view('layouts/header');
		$this->load->view('layouts/header-boot');
		$this->load->view('website/allresults');
		$this->load->view('layouts/footer');
	}

	public function result_form() {
		$this->load->view('layouts/header');
		$this->load->view('website/result_form');
		$this->load->view('layouts/footer');
	}

	public function show_result() {
		$this->load->view('layouts/header');
		$this->load->view('website/show_result');
		$this->load->view('layouts/footer');
	}

	public function search() {
		$result_id = $this->input->post('id');
		$cnic = $this->input->post('cnic');

		$fetch_user = $this->WebsiteModel->fetch_user_id($cnic);
		if($fetch_user) {
			foreach($fetch_user as $us) {
				$user_id = $us->id;
			}
			$project_id = $this->WebsiteModel->resultt($result_id)['name'];
			$search = $this->WebsiteModel->search_result($user_id, $project_id);
			if($search) {
				$this->session->set_flashdata('warning', 'Result found');
					return redirect(base_url().'website/Results/show_result?id='.$result_id.'&cnic='.$cnic.'&user_id='.$user_id);
			} else {
				$this->session->set_flashdata('warning', 'result not found');
					return redirect(base_url().'website/Results/result_form?id='.$result_id);
			}
		} else {
			$this->session->set_flashdata('warning', 'cnic not found');
					return redirect(base_url().'website/Results/result_form?id='.$result_id);
		}	
	}

}


?>