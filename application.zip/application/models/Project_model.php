<?php

class Project_model extends CI_Model{

    function check($cnic){
        $this->db->where('CNIC',$cnic);
        $query=$this->db->get('list_loralai_center');
        if ($query) {
         return $query->row();
        }
    }

    function verify($phone){
        $this->db->where('Phone_No',$phone);
        $query=$this->db->get('list_loralai_center');
        if($query){
            return $query->row();
        }
        else{
            return 'No Data Found';
        }
    }

    function validate()
    {
        $arr['username'] = $this->input->post('username');
        $arr['password'] = $this->input->post('password');
        return $this->db->get_where('admins',$arr)->row(); 
    }

    function updateProject($data){
        $CNIC=$data['CNIC'];
        $insert_data['photo']=$data['photo'];
        $this->db->where('CNIC',$CNIC);
        $query=$this->db->update('list_loralai_center',$insert_data);
        if ($query) {
            return true;
        }
        else{
            return false;
        }
    }

    function quettaResult($cnic){
        $this->db->where('CNIC',$cnic);
        $query=$this->db->get('list_quetta_center');
        if ($query) {
         return $query->row();
        }
    }

     function getRes($phone){
        $this->db->where('Phone_No',$phone);
        $query=$this->db->get('list_quetta_center');
        if($query){
            return $query->row();
        }
    
    }
}
?>