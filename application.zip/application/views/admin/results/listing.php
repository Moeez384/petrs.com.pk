<?php
if(!empty($_SESSION['id'])) {
?>


<br><br>
<form method="POST">
<div class="card ml-3 mr-4 bg-white border border-0 rounded-0 shadow" style="background-color: #05386B;">
	<div class="card-body table-responsive">
		<h3 style="color: #05386B;" class="text-center">RESULTS LIST</h3>
	</div>
</div>
<br>
<div class="card ml-3 mr-4 border border-0 rounded-0 shadow">
<e style="font-size: 14px; color: #000">
	<div class="card-body table-responsive">
		<button style="float:right; background-color: #05386B; color: white"  class="btn btn-sm rounded-0 mb-4" name="add">Add Result</button>
		<table id="myTable" class="table table-bordered table-hover" style="width: 100%; color:black">
			<thead>
			<tr style="background-color: whitesmoke">
				<th style="width: 140px;" class="text-center"><i class="fas fa-tasks"></i>&nbsp;Actions&nbsp;&nbsp;</th>
				<th class="text-center"><i class="fas fa-building"></i>&nbsp;Project Name</th>
				<th class="text-center"><i class="fas fa-building"></i>&nbsp;Result Name</th>
				<th class="text-center"><i class="fas fa-building"></i>&nbsp;Total Marks</th>
			</tr>
		</thead>
		<tr>
		<?php
		$all_results = $this->ProjectsModel->fetch_all_results();
		if($all_results) {
			foreach($all_results as $pr) {
				$prname = $this->ProjectsModel->result_name($pr->project);
				$name1 = $this->ProjectsModel->get_post($pr->name);
		?>	
			<td class="text-center"><a href="<?php echo base_url();?>admin/Results/edit_result?id=<?php echo $pr->id?>" title="update"><i class="fas fa-edit text-primary" style="font-size: 18px"></i></a>&nbsp;<a href="<?php echo base_url();?>admin/Results/add_user_result?id=<?php echo $pr->name?>" title="add users"><i class="fas fa-arrow-right" style="font-size: 18px"></i></a>
				&nbsp;<a href="<?php echo base_url();?>admin/Results/list_user_result?id=<?php echo $pr->id?>" title="users list"><i class="fa fa-list" aria-hidden="true" style="font-size: 18px"></i></a>
			</td>
			<td class="text-center"><?php echo $prname; ?></td>
			<td class="text-center"><?php echo $name1;?></td>
			<td class="text-center"><?php echo $pr->total_marks;?></td>
		</tr>
		<?php }} ?>
		</table>
	</div>
	</div>
</div>
</div>
</form>

<?php
if(isset($_POST['add'])) {
	redirect('admin/Results/add_result');
}

?>

<script type="text/javascript">
	$(document).ready(function() {
    $('#myTable').DataTable();
} );
</script>

<?php } else {
  redirect(base_url().'admin/Signin');
}
?>