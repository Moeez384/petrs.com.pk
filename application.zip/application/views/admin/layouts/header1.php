<header class="main-header">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

  <!-- Logo -->
  <a href="dashboard/" class="logo">
      <label>CSS</label>
   </a>

    <!-- Top bar -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <!-- Top rigth icons grid -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
             
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="true">
                  <label id="lbl-admin">AD</label>
                </a>
              <!--<ul class="dropdown-menu animated fadeInDown">
                  <li role="presentation">
                  <a role="menuitem" tabindex="-1" href="<?= base_url() ?>profile?change_password=true"> <i class="fa fa-key"></i>Change Password</a></li>
                  <li class="divider"></li>
                  <li role="presentation">
                  <a role="menuitem" tabindex="-1" href="<?= base_url()?>logout"> <i class="fa fa-power-off text-red"></i>Sign out</a></li>
                </ul>-->
             </li>
        </ul>
      </div>
   
    </nav>

</header>