<?php
	$lay_fixed = 'navbar-fixed-bottom';
?>

<footer class="main-footer"> <strong>
  
  <?php echo date('Y');?>
  
  © <b></b>
  </strong> </footer>
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark"> 
  <!-- Tab panes -->
  <div class="tab-content"> 
    <!-- Home tab content -->
    <div class="tab-pane" id="control-sidebar-home-tab"> </div>
    <!-- /.tab-pane --> 
  </div>
</aside>
<!-- /.control-sidebar --> 
