<?php
include('includes/header.php');
?>

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Edit Roll No Slip</h4>
	   </div>
	</div>
	   
	   <?php
if ($this->session->flashdata('verify')) {
  ?>
  <div align="center" style="color: #FFF" class="btn-success">
    <?php
    echo $this->session->flashdata('verify');
    ?>
    </div>
    <?php
}
?>
     <?php
if ($this->session->flashdata('inserted20')) {
  ?>
  <div align="center" style="color: #FFF" class="btn-success">
    <?php
    echo $this->session->flashdata('inserted20');
    ?>
    </div>
    <?php
}
?>
    <?php
if ($this->session->flashdata('test2')) {
  ?>
  <div align="center" style="color: #FFF" class="btn-danger">
    <?php
    echo $this->session->flashdata('test2');
    ?>
    </div>
    <?php
}
?>
    <!-- End Breadcrumb-->
	<form action="<?php echo base_url('website_controller/showDetails') ?>" method="POST" enctype="multipart/form-data">
		<div class="row">
			<div class="col-lg-6">
			   <div class="card">
                 <div class="card-header text-uppercase">CNIC</div>
                  <div class="card-body">
				    <input type="text"  required name="cnic" class="form-control form-control-rounded">
				  </div>
				</div>
			</div>
		</div>
        
		<div class="row">
      <div class="col-lg-6">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
</form>
<br>
</div>
</div>

<?php
include('includes/footer.php');
?>