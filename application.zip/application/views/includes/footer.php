<!--Start footer-->
  <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2021 Dashtreme Admin
        </div>
      </div>
    </footer>
  <!--End footer-->
  
<div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">

      <p class="mb-0">Gaussion Texture</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>

      <p class="mb-0">Gradient Background</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme7"></li>
        <li id="theme8"></li>
        <li id="theme9"></li>
        <li id="theme10"></li>
        <li id="theme11"></li>
        <li id="theme12"></li>
		<li id="theme13"></li>
        <li id="theme14"></li>
        <li id="theme15"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
   
  </div><!--End wrapper-->

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url('test/js/jquery.min.js') ?>"></script>
  <script src="<?php echo base_url('test/js/popper.min.js') ?>"></script>
  <script src="<?php echo base_url('test/js/bootstrap.min.js') ?>"></script>
	
 <!-- simplebar js -->
  <script src="<?php echo base_url('test/plugins/simplebar/js/simplebar.js') ?>"></script>
  <!-- sidebar-menu js -->
  <script src="<?php echo base_url('test/js/sidebar-menu.js') ?>"></script>
  <!-- loader scripts -->
  <script src="<?php echo base_url('test/js/jquery.loading-indicator.js') ?>"></script>
  <!-- Custom scripts -->
  <script src="<?php echo base_url('test/js/app-script.js') ?>"></script>
  <!-- Chart js -->
  
  <script src="<?php echo base_url('test/plugins/Chart.js/Chart.min.js') ?>"></script>
  <!-- Vector map JavaScript -->
  <script src="<?php echo base_url('test/plugins/vectormap/jquery-jvectormap-2.0.2.min.js') ?>"></script>
  <script src="<?php echo base_url('test/plugins/vectormap/jquery-jvectormap-world-mill-en.js') ?>"></script>
  <!-- Easy Pie Chart JS -->
  <script src="<?php echo base_url('test/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js') ?>"></script>
  <!-- Sparkline JS -->
  <script src="<?php echo base_url('test/plugins/sparkline-charts/jquery.sparkline.min.js') ?>"></script>
  <script src="<?php echo base_url('test/plugins/jquery-knob/excanvas.js') ?>"></script>
  <script src="<?php echo base_url('test/plugins/jquery-knob/jquery.knob.js') ?>"></script>
    
    <script>
        $(function() {
            $(".knob").knob();
        });
    </script>
  <!-- Index js -->
  <script src="<?php echo base_url('test/js/index.js') ?>"></script> 
</body>
</html>
