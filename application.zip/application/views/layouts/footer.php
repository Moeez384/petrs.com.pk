<!-- Footer Section -->
<div id="bottom_seciton">
	<div id="footer">
		<!--Find your way -->	
        	<div class="find_your_way">
				<h5>Find your Way</h5>        
        		<ul>
        			<li><a href="#">Home</a></li>
        			<li><a href="#">Site map</a></li>
        			<li><a href="#">International students</a></li>
        			<li><a href="#">About Collegeme</a></li>
        			<li><a href="#">Current Students</a></li>
                	<li><a href="#">Staff</a></li>
        		</ul>
			</div>    
    	<!-- Help and Support -->	
        	<div class="help_support">
				<h5>Help &amp;Support</h5>        
        		<ul>
        			<li><a href="#">Academic Calendar</a></li>
        			<li><a href="#">Bookstore</a></li>
        			<li><a href="#">Colleges &amp; Schools</a></li>
        			<li><a href="#">Courses</a></li>
        			<li><a href="#">Professional Programs</a></li>
                	<li><a href="#">Our Help Desk</a></li>
        		</ul>
			</div>    
    	<!-- Quick Links -->	
        	<div class="quick_links">
				<h5>Quick Links</h5>        
        		<ul>
        			<li><a href="#">Directories</a></li>
        			<li><a href="#">Site map</a></li>
        			<li><a href="#">cMail | xMail</a></li>
        			<li><a href="#">Campus Notices</a></li>
        			<li><a href="#">Emergency Information</a></li>
                	<li><a href="#">Staff</a></li>
        		</ul>
			</div>    
    	<!-- Addmission -->	
        	<div class="Addmissoin">
				<h5>Addmission</h5>        
        		<ul>
        			<li><a href="#">Business</a></li>
        			<li><a href="#">Financial Aid</a></li>
        			<li><a href="#">Graduate</a></li>
        			<li><a href="#">Law</a></li>
        			<li><a href="#">Undergraduate</a></li>
                	<li><a href="#">School</a></li>
        		</ul>
			</div>    
    	<!-- Contact Us -->	
        	<div class="contact_us">
				<h5>Contact Us</h5>        
        		<ul>
        			<li class="telephone_no">0302-3826468</li>
        			<li class="telephone_no">0333-2689843</li>
        			<li class="telephone_no">0302-3890590</li>
        			<!--<li  class="mailing_address">-->
           <!--         	info@petrs.com.pk-->
           <!--         </li>-->
        			<li class="email_address"><a href="#">info@petrs.com.pk</a></li>
        			<li class="googlemaps"><a href="contact.html">Office No. B-03 Jinnah Appartements  MA  Jinnah Road Quetta, Balochistan. </a></li>
        		</ul>
			</div>    
   		<div class="clear"></div>     
    </div>
</div>
<!-- Bototm seciton -->
	<div id="bottom_Section">
	<!-- page bottm -->
       	<div id="pagebottom">
    		<!-- copyright -->
            <div class="copyright">&copy; 2020 <a href="#">PETRS</a> All Rights Reserved<a href="http://bilalnetwork.com/"> Bilal Network </a></div>
            	<a href="#" class="top">Top</a>
    			<!-- Social Networks -->
            	<div class="socail_networks">
        			<ul>
            			<li class="servcies">Follows us our servcies</li>
            			<li><a href="#"><img src="<?php echo base_url();?>assets/images/facebook_icon.gif"  alt="" /> </a></li>
                		<li><a href="#"><img src="<?php echo base_url();?>assets/images/linkedin_icon.gif"  alt="" /> </a></li>
                		<li><a href="#"><img src="<?php echo base_url();?>assets/images/twitter_icon.gif"  alt="" /> </a></li>
                		<li><a href="#"><img src="<?php echo base_url();?>assets/images/rssfeed_icon.gif"  alt="" /> </a></li>
                		<li><a href="#"><img src="<?php echo base_url();?>assets/images/social_icon.gif"  alt="" /> </a></li>
               		</ul>
        		</div>
             <div class="clear"></div>     	
    	</div>
	</div>
</body>


</html>