<style>
    .tab_content li .descripton {
    width: 253px;
    float: left;
}
.popup-heading h3{
    position: relative;
}
.popup-heading h3:before{
background-image: url(https://icon-library.net//images/new-icon-gif/new-icon-gif-3.jpg);
    background-size: 58px 28px;
    display: inline-block;
    width: 79px;
    left: 71px;
    height: 81px;
    position: absolute;
    content: "";
    background-repeat: no-repeat;
    top: 1px;
}
.popup-heading h3:after{
background-image: url(https://icon-library.net//images/new-icon-gif/new-icon-gif-3.jpg);
    background-size: 58px 28px;
    display: inline-block;
    width: 79px;
    right: 54px;
    height: 81px;
    position: absolute;
    content: "";
    background-repeat: no-repeat;
    top: 1px;
}
.workarea h4, h3, h1{
  color:#fff !important;
}
.banner_des{
    width: 554px;
    height: 66px;
    padding-left: 20px;
}
.banner_des p {
    padding-right: 0px;
}
.slider1 li img {
    width: unset !important;
    height: 68px;
}
.blink_me {
  animation: blinker 2s linear infinite;
}

@keyframes blinker {
  50% {
    opacity: 0;
  }
}
</style>

                    <div class="clear"></div>
        <!-- Col1 -->
                  <div class="col1">
                      <!-- Banner -->
                          <div id="banner">
                <div id="slider2">
                                  <!-- <div class="contentdiv"> -->
                                      <a href="#"><img src="<?php echo base_url();?>assets/images/banner.jpg" alt="" /></a>
                                        <div class="banner_des">
                                        
                                          <p>PETRS have relayed exhaustive efforts in ensuring a testing structure that is fair and equitable. All our services including individual test questions, assessments, and associated services are evaluated under stringent checks. Internal monitoring checks are put in place to guarantee a fair, transparent and equitable testing infrastructure. </p>

                                        </div>
                                   <!--  </div>  -->
                                    <div class="contentdiv">
                                      <a href="#"><img src="<?php echo base_url()?>assets/images/banner1.jpg" alt="" /></a>
                                        <div class="banner_des">
                                          <h4>PETRS could not have reached the present heights without the support of HEC. </h4>
                                          <p>It would be pertinent to compliment the NTS Governing Board. </p>
                                        </div>
                                    </div>
                                    <div class="contentdiv">
                                      <a href="#"><img src="<?php echo base_url()?>assets/images/banner2.jpg" alt="" /></a>
                                        <div class="banner_des">
                                          <h4>The PETRS website reflects our twelve years of success in operation.</h4>
                                          <p> The PETRS website reflects our twelve years of success in operation. Over this period, being a leading testing and assessment organization of Pakistan. </p>
                                        </div>
                                    </div>
                                    <div class="contentdiv">
                                      <a href="#"><img src="<?php echo base_url()?>assets/images/banner3.jpg" alt="" /></a>
                                        <div class="banner_des">
                                          <h4>It would be pertinent to compliment the PETRS Governing Board </h4>
                                          <p>I would also like to express my gratitude to the sincerity and dedication of all the employees who, through their unflinching faith and successive efforts.</p>
                                        </div>
                                    </div>
                                    <div class="contentdiv">
                                      <a href="#"><img src="<?php echo base_url()?>assets/images/banner4.jpg" alt="" /></a>
                                        <div class="banner_des">
                                          <h4>PETRS could not have reached the present heights without the support of HEC. </h4>
                                          <p>It would be pertinent to compliment the NTS Governing Board. </p>
                                        </div>
                                    </div>
                                  </div>
                                  <div id="paginate-slider2" class="pagination">
                  </div>
                            <script type="text/javascript" src="js/slider.js" ></script>

               </div>
               <div class="popbox">
                 <div class="dimmer"></div>

                 <div class="modal">
                   <div class="outgap">

                     <div class="workarea">
                       <div class="close_button">&times;</div>
                       <div class="popup-heading" style="text-align: center;">
                        <h1> Balochistan Residential College Loralai (BRC)  </h1>
                        </br>
                        <h4 class="blink_me">Please Search Your Roll No Slip With Your Father CNIC</h4>
                        </br>
                        </br>
                         <h3 >Entry Test (2021) In Loralai </h3>
                       </div>
                       <div class="pz-popup-box">
                         <a href="<?php echo base_url()?>website/Signin/CheckRollNo" target="_blank">Download Roll No Slip</a>
                       </div>
                        <div class="popup-heading" style="text-align: center;margin-top:20px;">
                        
                        <h3>Entry Test (2021) In Quetta</h3>
                       </div>
                       <div class="pz-popup-box">
                         <a href="<?php echo base_url()?>website/Signin/quettaList" target="_blank">Download Roll No Slip</a>
                       </div>

                    <!--   <div style="text-align: center;"><a role="button" href="#" onClick="PopBox.hide(); return false;">Close</a></div>
-->
                     </div>
                   </div>
                 </div>
               </div>
                         <!-- Content Links -->
                          <div class="content_links">
                              <ul>
                                <li><a class="our_university" href="#">Our University</a></li>
                                    <li><a class="admission" href="#">Admissions</a></li>
                                    <li><a class="accommodaiton" href="#">Accommodations</a></li>
                                    <li><a class="community" href="#">Community</a></li>
                                    <li><a class="schorship" href="#">Scholorships</a></li>
                                    <li class="last"><a class="take_tour" href="#">Take a Tour</a></li>
                                </ul>
                            </div>
                         <!-- Content Heading -->
                           <!-- Content Heading -->
                          <div class="catogary_images">
                              <div class="image1">
                                <div class="pz-style">
                                <a href="<?php echo base_url()?>website/Projects">
                                  <img src="<?php echo base_url()?>assets/images/1icon.png" alt="" />
                                  <h5>ALL PROJECTS</h5>
                                </a>
                              </div>
                              </div>

                              <div class="image2">
                                <div class="pz-style">
                                <a href="<?php echo base_url()?>website/Results">
                                  <img src="<?php echo base_url()?>assets/images/2icon.png" alt="" />
                                  <h5>ALL RESULTS</h5>
                                </a>
                              </div>
                              </div>

                              <div class="image3">
                                <div class="pz-style">
                                <a href="<?php echo base_url()?>website/Projects/new_projects">
                                  <img src="<?php echo base_url()?>assets/images/3icon.png" alt="" />
                                  <h5>NEW PROJECTS</h5>
                                </a>
                              </div>
                              </div>

                              <?php if(empty($_SESSION['id'])) { ?>
                              <div class="image4">
                                <div class="pz-style">
                                <a href="<?php echo base_url()?>website/Signin/AllRollNoSlip">             
                                <img src="<?php echo base_url()?>assets/images/4icon.png" alt="" />
                                  <h5>ROLL NO SLIP</h5>
                                </a>
                              </div>
                             </div>
                            <?php } else { ?>
                              <div class="image4">
                                <div class="pz-style">
                                <a href="<?php echo base_url()?>website/Rollnoslips">
                                  <img src="<?php echo base_url()?>assets/images/4icon.png" alt="" />
                                  <h5>ROLL NO SLIP</h5>
                                </a>
                              </div>
                             </div>
                            <?php } ?>
                           </div>
                          <div class="content_heading">
                              <div class="heading"><h2>Welcome to PETRS</h2> </div>
                              </div>
                         
                              <p>At PETRS, we also carry out academic testing service by dealing with university students by holding tests online and offline. If you are preparing for any kind of exam pretests. No matter what the subject or course you study, there are online tests available in your respective fields. At PETRS, we give you the benefits of preparing yourself through our services by offering career/academic test. Our test is cost effective and effective way to study, covers numerous fields of study, convenient and easily accessible, and helps you find problem areas. When you take PETRS online or offline tests, you will be able to identity your weak spots. This will help you figure out where you need to work harder to improve your grade. If you study without preparing yourself with our testing service, then you will never know whether your brain has retained the study material properly or not. Online tests are very beneficial for those who want to do well in their respective careers or academic studies. So be sure to reach out us at Prominent Educational Testing & Recruitment Services</p>
                         <p>It is a known fact that the success of an employer and a company as a whole depends largely on the quality and reliability of its employees. This is the reason why employers must invest time and even money in the recruitment and interview process. Doing so would ensure that only the process. Doing so would ensure that only the best possible candidate will be considered for a particular job. When it comes to a screening for potential employees tests. These tests can measure what is called the KSA – Knowledge, skills and abilities of the job candidates. At PETRS, Our employment tests are generally offline and online tests, which include interviews, personality tests, skill tests, psychological tests, performance tests and so on. A hiring process that is poorly designed is much like a recruitment process based on flipping a coin. Employers are well aware that the impact of inefficient recruitment decisions can have costly and detrimental outcomes, which may include expensive training cost, decrease in overall productivity, increase in employee replacement, and increase legal exposure. Benefits of assessment test ensure that your company is making better hiring decisions. It can determine whether or not an employee can meet your criterion for maintaining high productivity.</p>
                          <div class="clear"></div>
                             <!-- Content Block -->
                            <div class="contentblock">
                                  <!-- Tabs -->
                                      <div class="tabwrapper">
                                          <div class="tabs_links">
                                              <ul>
                                                  <li><a  href="#tab1">New Results</a></li>
                                                    <li><a href="#tab2">Top News</a></li>
                                             <!--       <li><a href="#tab3">Tweets</a></li>
                                                    <li ><a class="nobg" href="#tab4">Blog</a></li> -->
                                                </ul>
                                            </div>
                                            <div class="tab_content" id="tab1" style="display:none" >
                                              <ul>
                                                <?php
                                                $top_res = $this->WebsiteModel->fetch_top_res();
                                                if($top_res) {
                                                  foreach($top_res as $rs) {
                                                    $res_name = $this->WebsiteModel->get_postt_name($rs->name);
                                                ?>
                                                  <li>

                                                         <div class="descripton">
                                                          <h6><a href="<?php echo base_url()?>website/Results"><?php echo $res_name;?></a></h6>
                                                            <em>(Test Date <?php echo $rs->test_date ?>)</em>
                                                        </div>
                                                    </li>
                                                    <?php }} ?>
                                                </ul>
                                                <div class="clear"></div>
                                            </div>

                                            <div class="tab_content" id="tab2" style="display:none" >
                                              <ul>
                                                <?php
                                                $top_news = $this->WebsiteModel->fetch_top_news();
                                                if($top_news) {
                                                  foreach($top_news as $nw) {
                                                ?>
                                                  <li>
                                                   <div class="descripton">
                                                          <h6><a href="<?php echo base_url()?>website/News"><?php echo $nw->title; ?></a></h6>
                                                            <em>(Posted on <?php echo $nw->created_date ;?>)</em>
                                                            <p>
                                                              <?php echo (strlen($nw->details) > 28) ? substr($nw->details,0,28).'...' : $nw->details;?>
                                                            </p>

                                                        </div>
                                                  </li>
                                                    <?php }} else { ?>
                                                      <li>
                                                   <div class="descripton">
                                                          <h6><a href="news.html"></a></h6>
                                                            <em></em>
                                                            <p>

                                                            </p>

                                                        </div>
                                                  </li>
                                                    <?php } ?>
                                                </ul>
                                                <div class="clear"></div>
                                            </div>
                                        </div>
                                        <div class="clear"></div>
                                  </div>

                        <!-- col1 ends -->
                    </div>
               <!-- Col2 -->
                 <div class="col2">
                      <div class="ads">
                          <!-- <h3 style="padding-top: 50%;"><a style="color: #01411c !important;" href="#">Advertisement</a></h3> -->
                          <img style="height: 319px; width: 240px;" src="<?php echo base_url()?>assets/images/BRC_loralai_by_Petrs.JPG"  alt="" />
                        </div>
                        <br><br>
                          <!-- Top Student -->
                            <div class="left_circle">

                                      <ul>
                                          <li><a href="nat-test.html">UST</a></li>
                                          <li><a href="gat-test.html">GST </a></li>
                                          <li><a href="gat-subject-test.html">CST </a></li>

                                        </ul>

                                  </div>

                                <div class="college_gallery">
                                  <h5>On Going Projects</h5>

                                      <ul class="container">
                                      <?php
                                        $ongoing_projects = $this->WebsiteModel->fetch_ongoing_projects();
                                        if($ongoing_projects) {
                                        foreach($ongoing_projects as $pr) {
                                      ?>
                                      <li>
                                            <div class="description">
                                              <a href="<?php echo base_url()?>website/Projects" class="pz-title"><?php echo $pr->name; ?></a>
                                                <a class="gray" href="<?php echo base_url()?>website/Projects"><em>(Posted on <?php echo $pr->created_date; ?>)</em></a>
                                            </div>
                                        </li>
                                        <?php }} else { ?>
                                      <li>
                                            <div class="description">
                                              <a href="#" class="pz-title"></a>
                                                <a class="gray" href="#"><em></em></a>
                                            </div>
                                        </li>
                                    </ul>
                                    <?php } ?>
                                </div>
                        <div class="clear"></div>

                        <div class="college_gallery">
                                  <h5>Completed Projects</h5>
                                  <ul class="container">
                                  <?php
                                    $completed_projects = $this->WebsiteModel->fetch_completed_projects();
                                    if($completed_projects) {
                                      foreach($completed_projects as $pr) {
                                  ?>
                                      <li>
                                          <div class="description">
                                             <a href="<?php echo base_url()?>website/Projects" class="pz-title"><?php echo $pr->name; ?></a>
                                              <a class="gray" href="<?php echo base_url()?>website/Projects"><em>(Posted on <?php echo $pr->created_date; ?>)</em></a>
                                          </div>
                                      </li>
                                  <?php }} else { ?>
                                      <li>
                                          <div class="description">
                                             <a href="#" class="pz-title"></a>
                                              <a class="gray" href="#"><em></em></a>
                                          </div>
                                      </li>
                                        <?php } ?>

                                    </ul>
                                </div>
                        <div class="clear"></div>
            <!--col2 ends -->
                  </div>
                <div class="clear"></div>
      <!-- Slder -->
              <div class="image_scroll">
                  <a class="leftarrow" href="#"><img src="<?php echo base_url()?>assets/images/left_arrow.gif"  alt="" /></a>
                      <div class="slider1">
                          <ul>
                          <li><a href="#"><img src="<?php echo base_url()?>assets/images/Brc.png"  alt="" /></a></li>
                          <li><a href="#"><img src="<?php echo base_url()?>assets/images/slider2.gif"  alt="" /></a></li>
                          <li><a href="#"><img src="<?php echo base_url()?>assets/images/slider3.gif"  alt="" /></a></li>
                          <li><a href="#"><img src="<?php echo base_url()?>assets/images/slider4.gif"  alt="" /></a></li>
                          <li><a href="#"><img src="<?php echo base_url()?>assets/images/slider5.gif"  alt="" /></a></li>
                          <li><a href="#"><img src="<?php echo base_url()?>assets/images/slider6.gif"  alt="" /></a></li>
                        </ul>
                        </div>
                    <a class="rightarrow" href="#"><img src="<?php echo base_url()?>assets/images/right_arrow.gif"  alt="" /></a>
                </div>
            </div>
    <div class="clear"></div>
  </div>
</div>
<script>
// <![CDATA[
doInit(function() {
  if (typeof $=="undefined") return 1;

  PopBox.init({
    auto_show: 15,         // in milliseconds. 15000 milliseconds = 15 seconds. 0 = disabled.
    auto_close: 0,        // in milliseconds. 60000 = 60 seconds. 0 = disabled.
    show_on_scroll_start: 48, // starting scroll position in percents, between 0% and 100%. Both 0 = disabled.
    show_on_scroll_end: 52,   // ending scroll position. Eg 40..60 means that popbox will appear when any part of page between 40% and 60% is appeared in the viewport.
    closeable_on_dimmer: true,
    auto_start_disabled: false,
  });
}, 1);
// ]]>
</script>
